import './App.css';
export default function App() {
  return <h1>HearDiary MVP Ready</h1>;
}