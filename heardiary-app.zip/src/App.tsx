import React from 'react';

export default function App() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif', textAlign: 'center' }}>
      <h1>HearDiary MVP</h1>
      <p>This is a minimal Vite + React + TypeScript setup.</p>
    </div>
  );
}